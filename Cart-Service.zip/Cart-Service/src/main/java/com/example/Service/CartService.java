package com.example.Service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import com.example.Repository.CartRepository;
import com.example.Repository.ProductRepository;
import com.example.entity.Cart;
import com.example.entity.ProductEntity;

import jakarta.transaction.Transactional;

@Service
public class CartService {

	@Autowired
	private CartRepository repository;
	@Autowired
	private RestTemplate restTemplate;
	
	private static final String url = "http://localhost:8087/product/getproduct/";

	public Cart addToCart(Cart cart) {

		ProductEntity product = getProductDetails(cart.getProductId());
		cart.setCreatedAt(new Date());
		cart.setProduct(product);

		return  repository.save(cart);

	}
	@Transactional
	public Cart addToCartById(Long productId) {
	 
	    // Check if a cart for the product already exists with "N" order status
	    Cart existingCart = repository.findByProductIdAndOrderStatus(productId, "N");

	    if (existingCart != null) {
	        // Cart for the product already exists, update quantity or any other information
	        int newQuantity = existingCart.getQuantity() + 1; // Assuming quantity should be incremented by 1
	        existingCart.setQuantity(newQuantity);
	        // Do not set the cartId here
	        return repository.save(existingCart);
	    } else {
	        // Cart for the product doesn't exist, create a new cart entry
	        ProductEntity product = getProductDetails(productId);
	        Cart newCart = new Cart();
	        newCart.setProductId(productId);
	        newCart.setProduct(product);
	        newCart.setCreatedAt(new Date());
	        newCart.setQuantity(1);
	        newCart.setOrderStatus("N");
	        return repository.save(newCart);
	    }
	}
	private Long generateUniqueCartId() {
	    // Convert the UUID string to a long value
	    return Math.abs(java.util.UUID.randomUUID().getMostSignificantBits());
	}

	public List<Cart> getAllCarts() {
		List<Cart> allCarts = repository.findAll();
		List<Cart> filteredCarts = allCarts.stream()
				.filter(cart -> !"Y".equals(cart.getOrderStatus()))
				.collect(Collectors.toList());
		return filteredCarts;
	}
	public void deleteCart(Long cartId) {
		repository.deleteById(cartId);
	}
//	public void UpdateCart(Long cartId) {
//		repository.updateCartStatus(cartId,"Y");
//		
//	}

	
	private ProductEntity getProductDetails(Long productId) {
		
		String productApiUrl = url + productId;
		ResponseEntity<ProductEntity> responseEntity = restTemplate.getForEntity(productApiUrl, ProductEntity.class);

		if (responseEntity.getStatusCode() == HttpStatus.OK) {
			return responseEntity.getBody();
		} else {
			throw new RestClientException("Failed to get product details. Status code: " + responseEntity.getStatusCode());
		}
	}
	
	public Optional<Cart> getCartById(Long cartId)
	{
		return repository.findById(cartId);
	}
	 public void UpdateCart(Long cartId, String orderStatus) {
	        Optional<Cart> optionalCart = repository.findById(cartId);

	        if (optionalCart.isPresent()) {
	            Cart cart = optionalCart.get();
	            cart.setOrderStatus(orderStatus);
	            repository.save(cart);
	        } else {
	            throw new RuntimeException("Cart with ID " + cartId + " not found");
	        }
	    }

}
