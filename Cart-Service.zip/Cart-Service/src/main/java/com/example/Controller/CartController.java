package com.example.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.Service.CartService;
import com.example.entity.Cart;
import jakarta.transaction.Transactional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@Transactional
@RequestMapping("/cart")
public class CartController {

    private static final Logger logger = LoggerFactory.getLogger(CartController.class);

    @Autowired
    private CartService cartService;

    @GetMapping("/getCartDetails")
    public ResponseEntity<List<Cart>> getAllCarts() {
        logger.info("Fetching all carts");
        List<Cart> carts = cartService.getAllCarts();
        return ResponseEntity.ok(carts);
    }

    @PostMapping("/add")
    public ResponseEntity<Cart> addToCart(@RequestBody Cart cart) {
        logger.info("Adding cart to the system: {}", cart);
        Cart addedCart = cartService.addToCart(cart);
        return ResponseEntity.ok(addedCart);
    }

    @PostMapping("/add-by-id/{productId}")
    public ResponseEntity<Cart> addToCartById(@PathVariable Long productId) {
        logger.info("Adding cart to the system by product id: {}", productId);
        Cart addedCart = cartService.addToCartById(productId);
        return ResponseEntity.ok(addedCart);
    }

    @DeleteMapping("/delete/{cartId}")
    public ResponseEntity<Void> deleteCart(@PathVariable Long cartId) {
        logger.info("Deleting cart with ID: {}", cartId);
        cartService.deleteCart(cartId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/getcart/{cartId}")
    public Optional<Cart> getProductById(@PathVariable Long cartId) {
        logger.info("Fetching cart details for ID: {}", cartId);
        return cartService.getCartById(cartId);
    }

    @PutMapping("/update-cart/{cartId}/{orderStatus}")
    public ResponseEntity<Void> updateCartStatus(@PathVariable Long cartId, @PathVariable String orderStatus) {
        logger.info("Updating cart status for ID: {} to {}", cartId, orderStatus);
        cartService.UpdateCart(cartId, orderStatus);
        return ResponseEntity.noContent().build();
    }
}
