package com.example.OrderService.orderEntity;

import jakarta.persistence.*;

@Entity
@Table(name = "product",schema = "shopping")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "productid")
	private Long productId;

	@Column(name = "productname")
	private String productName;

	@Column(name = "productdescription")
	private String productDescription;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}