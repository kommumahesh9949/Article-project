package com.example.OrderService.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.OrderService.orderEntity.Order;

public interface OrderRepository  extends JpaRepository<Order,Long>{
//	@Modifying
//    @Query("UPDATE Order o SET o.cartId = null WHERE o.cartId = :cartId")
//    void updateCartIdForOrders(@Param("cartId") Long cartId);
}
