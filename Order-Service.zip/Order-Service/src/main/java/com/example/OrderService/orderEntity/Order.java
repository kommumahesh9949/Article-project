package com.example.OrderService.orderEntity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "order_entity")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "orderid")
    private Long orderId;

    @Column(name = "userid")
    private Long userId;

    @Column(name = "cartid", nullable = false)
    private Long cartId;
    @Column(name = "productid")
    private Long productId;

    @Column(name = "createdat", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "updatedat")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    
    

    @ManyToOne
    @JoinColumn(name = "cartid", referencedColumnName = "cartid", insertable = false, updatable = false)
    private Cart cart;

    @ManyToOne
    @JoinColumn(name = "userid", referencedColumnName = "userid", insertable = false, updatable = false)
    private User user;
    @ManyToOne
    @JoinColumn(name = "productid", referencedColumnName = "productid", insertable = false, updatable = false)
    private Product product;
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getCartId() {
		return cartId;
	}
	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Cart getCart() {
		return cart;
	}
	public void setCart(Cart cart) {
		this.cart = cart;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Order(Long orderId, Long userId, Long cartId, Long productId, Date createdAt, Date updatedAt, Cart cart,
			User user, Product product) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.cartId = cartId;
		this.productId = productId;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.cart = cart;
		this.user = user;
		this.product = product;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}

