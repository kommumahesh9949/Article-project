package com.example.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.Entity.ProductEntity;
import com.example.Service.ProductService;
import com.example.ServiceImpl.ProductServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/product")
public class ProductController {

    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private ProductServiceImpl productService;

    @GetMapping("/getall-products")
    public List<ProductEntity> getAllProducts() {
        logger.info("Fetching all products");
        return productService.getAllProducts();
    }

    @GetMapping("/getproduct/{productId}")
    public Optional<ProductEntity> getProductById(@PathVariable Long productId) {
        logger.info("Fetching product by ID: {}", productId);
        return productService.getProductById(productId);
    }

    @PostMapping("/add-product")
    public ProductEntity saveProduct(@RequestBody ProductEntity product) {
        logger.info("Adding a new product: {}", product);
        return productService.saveProduct(product);
    }

    @PutMapping("/update-product/{productId}")
    public ProductEntity updateProduct(@PathVariable Long productId, @RequestBody ProductEntity updatedProduct) {
        logger.info("Updating product with ID {}: {}", productId, updatedProduct);
        return productService.updateProduct(productId, updatedProduct);
    }

    @DeleteMapping("/delete-product/{productId}")
    public void deleteProduct(@PathVariable Long productId) {
        logger.info("Deleting product with ID: {}", productId);
        productService.deleteProduct(productId);
    }
}
