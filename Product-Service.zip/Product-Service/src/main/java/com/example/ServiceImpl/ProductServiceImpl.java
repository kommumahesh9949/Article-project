package com.example.ServiceImpl;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.ProductEntity;
import com.example.Repository.ProductRepository;
import com.example.Service.ProductService;
@Service
public class ProductServiceImpl  implements ProductService{

	@Autowired
	private ProductRepository productRepository;

	@Override
	public ProductEntity saveProduct(ProductEntity product) {
		product.setCreatedAt(new Date());
		return productRepository.save(product);
	}

	@Override
	public ProductEntity updateProduct(Long productId, ProductEntity updatedProduct) {
		Optional<ProductEntity> existingProductOptional = productRepository.findById(productId);
	    if (existingProductOptional.isPresent()) {
	        ProductEntity existingProduct = existingProductOptional.get();
	      
	        updatedProduct.setCreatedAt(existingProduct.getCreatedAt());
	        // Set updatedAt before updating
	        updatedProduct.setUpdatedAt(new Date());
	        updatedProduct.setProductId(productId);

	        return productRepository.save(updatedProduct);
	    } else {
	        
	        return null;
	    }
	}

	@Override
	public Optional<ProductEntity> getProductById(Long productId) {
		return productRepository.findById(productId);
	}

	@Override
	public List<ProductEntity> getAllProducts() {
		return productRepository.findAll();
	}

	@Override
	public void deleteProduct(Long productId) {
		productRepository.deleteById(productId);

	}
//	 private String formatInIndianTimeZone(Date date) {
//	        ZonedDateTime zonedDateTime = ZonedDateTime.ofInstant(date.toInstant(), ZoneId.of("Asia/Kolkata"));
//	        return zonedDateTime.toString();
//	    }

}
