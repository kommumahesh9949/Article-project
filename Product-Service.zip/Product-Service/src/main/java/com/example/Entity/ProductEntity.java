package com.example.Entity;

import java.util.Date;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data @NoArgsConstructor @AllArgsConstructor
@Table(name = "product")

public class ProductEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "productid")
	private Long productId;

	@Column(name = "productname", length = 75, nullable = false)
	private String productName;

	@Column(name = "productdescription", length = 100)
	private String productDescription;

	@Lob
	@Column(name = "productimage")
	private byte[] productImage;

	@Column(name = "createdat", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;

	@Column(name = "updatedat")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;

}