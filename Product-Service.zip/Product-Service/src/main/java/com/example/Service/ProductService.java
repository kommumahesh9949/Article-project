package com.example.Service;

import java.util.List;
import java.util.Optional;

import com.example.Entity.ProductEntity;



public interface ProductService {
	
	public ProductEntity saveProduct(ProductEntity product);
	public ProductEntity updateProduct(Long productId, ProductEntity updatedProduct);
	public Optional<ProductEntity> getProductById(Long productId);
	public List<ProductEntity> getAllProducts();
	public void deleteProduct(Long productId);

}
