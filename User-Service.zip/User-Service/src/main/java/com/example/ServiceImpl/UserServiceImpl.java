package com.example.ServiceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.User;
import com.example.Entity.UserAuth;
import com.example.exception.NullUserException;
import com.example.exception.UserAlreadyExistException;
import com.example.exception.UserDoesnotExistException;
import com.example.repository.UserRepository;
import com.example.service.UserService;


@Service
public class UserServiceImpl implements UserService{

	@Autowired
	public UserRepository repository;
	@Override
	public User addUser(User user) {
//		if (user == null)
//			throw new NullUserException("Please Enter Data");
//		
//		Optional<User> checkUser = repository.findById(user.getUserName());
//		if (checkUser.isPresent())
//			throw new UserAlreadyExistException("user already exists");
		user.setCreatedat(new Date());

		repository.save(user);
		System.out.println("user Added Succesfully");
		return user;

	}

	public User userLogin(UserAuth auth) {
	    if (auth == null) {
	        throw new NullUserException("Please Enter Data");
	    }

	    List<User> userList = repository.findByUsername(auth.getUsername());

	    if (userList.isEmpty()) {
	        throw new UserDoesnotExistException("User does not exist");
	    }

	    for (User user : userList) {
	        if (user.getUsername().equals(auth.getUsername()) && user.getPassword().equals(auth.getPassword())) {
	            return user;
	        }
	    }

	    throw new UserDoesnotExistException("Invalid login ID or Password");
	}

	@Override
	public List<User> getUserDetails() {
		return repository.findAll();
	}
	public Optional<User> getUserById(Long userId) {
		return repository.findById(userId);
	}

}
