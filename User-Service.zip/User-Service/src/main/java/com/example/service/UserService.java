package com.example.service;


import java.util.List;
import java.util.Optional;

import com.example.Entity.User;
import com.example.Entity.UserAuth;

public interface UserService {
	
	public User addUser(User user);
	public User userLogin(UserAuth auth);
	public List<User> getUserDetails();
	public Optional<User> getUserById(Long userId);


}
