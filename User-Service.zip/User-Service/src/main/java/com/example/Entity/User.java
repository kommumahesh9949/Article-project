package com.example.Entity;

import java.util.Date;

import jakarta.persistence.*;

@Entity
@Table(name = "user",schema = "shopping")
public class User {
    @Id
    @Column(name = "userid")
    private long userid;

    @Column(name = "firstname", length = 50)
    private String firstname;

    @Column(name = "username", length = 50)
    private String username;

    @Column(name = "lastname", length = 50)
    private String lastname;

    @Column(name = "email", length = 50)
    private String email;

    @Column(name = "password", length = 32, nullable = false)
    private String password;

    @Column(name = "createdat", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdat;

    @Column(name = "updatedat")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedat;

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getCreatedat() {
		return createdat;
	}

	public void setCreatedat(Date createdat) {
		this.createdat = createdat;
	}

	public Date getUpdatedat() {
		return updatedat;
	}

	public void setUpdatedat(Date updatedat) {
		this.updatedat = updatedat;
	}

	public User(long userid, String firstname, String username, String lastname, String email, String password,
			Date createdat, Date updatedat) {
		super();
		this.userid = userid;
		this.firstname = firstname;
		this.username = username;
		this.lastname = lastname;
		this.email = email;
		this.password = password;
		this.createdat = createdat;
		this.updatedat = updatedat;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	
    
    
}

   

   