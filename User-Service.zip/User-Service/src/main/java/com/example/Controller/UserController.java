package com.example.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import com.example.Entity.User;
import com.example.Entity.UserAuth;
import com.example.ServiceImpl.UserServiceImpl;
import com.example.exception.UserValidationException;

import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/user")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserServiceImpl service;

    @PostMapping("/addUser")
    public ResponseEntity<User> addUser(@Valid @RequestBody User user, Errors error) {
        logger.info("Adding user: {}", user.getUsername());

        if (error.hasErrors()) {
            logger.warn("Invalid data provided for user creation");
            throw new UserValidationException("Invalid data provided");
        }

        User addedUser = service.addUser(user);
        logger.info("User added successfully. User details: {}", addedUser);
        return ResponseEntity.ok().body(addedUser);
    }

    @PostMapping("/userLogin")
    public ResponseEntity<User> loginUser(@RequestBody UserAuth auth) {
        logger.info("User login attempt for username: {}", auth.getUsername());
        
        User user = service.userLogin(auth);
        
        if (user != null) {
            logger.info("User login successful. User details: {}", user);
        } else {
            logger.warn("User login failed for username: {}", auth.getUsername());
        }

        return ResponseEntity.ok().body(user);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<User>> getAllDetails() {
        logger.info("Fetching all user details");
        List<User> list = service.getUserDetails();
        return ResponseEntity.ok().body(list);
    }

    @GetMapping("/getuser/{userId}")
    public Optional<User> getProductById(@PathVariable Long userId) {
        logger.info("Fetching user details for user ID: {}", userId);
        return service.getUserById(userId);
    }
}
